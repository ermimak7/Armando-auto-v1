/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Car, 
  Truck, 
  Calculator, 
  Plus, 
  Minus, 
  X, 
  ChevronRight, 
  Info,
  CheckCircle2,
  Wrench,
  Receipt,
  Settings,
  History,
  Upload,
  Save,
  Trash2,
  Download,
  FileText
} from 'lucide-react';
import { SERVICES as INITIAL_SERVICES, ServiceItem } from './data';

type VehicleType = 'automobile' | 'lightTruck' | 'mediumTruck' | 'heavyTruck';
type Tab = 'catalog' | 'history' | 'admin';

interface SavedRequest {
  id: string;
  date: string;
  vehicleType: VehicleType;
  services: ServiceItem[];
  total: number;
}

const VEHICLE_TYPES: { id: VehicleType; label: string; icon: any }[] = [
  { id: 'automobile', label: 'Automobile', icon: Car },
  { id: 'lightTruck', label: 'Light Truck', icon: Truck },
  { id: 'mediumTruck', label: 'Medium Truck', icon: Truck },
  { id: 'heavyTruck', label: 'Heavy Truck', icon: Truck },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('catalog');
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [savedRequests, setSavedRequests] = useState<SavedRequest[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>('automobile');
  const [selectedServices, setSelectedServices] = useState<ServiceItem[]>([]);
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);
  const [importText, setImportText] = useState('');

  // Initialize from LocalStorage
  useEffect(() => {
    const storedServices = localStorage.getItem('as_services');
    const storedRequests = localStorage.getItem('as_requests');
    
    if (storedServices) {
      setServices(JSON.parse(storedServices));
    } else {
      setServices(INITIAL_SERVICES);
    }

    if (storedRequests) {
      setSavedRequests(JSON.parse(storedRequests));
    }
  }, []);

  // Sync to LocalStorage
  useEffect(() => {
    if (services.length > 0) {
      localStorage.setItem('as_services', JSON.stringify(services));
    }
  }, [services]);

  useEffect(() => {
    localStorage.setItem('as_requests', JSON.stringify(savedRequests));
  }, [savedRequests]);

  const filteredServices = useMemo(() => {
    return services.filter(service => 
      service.descriptionEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.descriptionAm.includes(searchQuery) ||
      service.id.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery, services]);

  const toggleService = (service: ServiceItem) => {
    setSelectedServices(prev => {
      const exists = prev.find(s => s.id === service.id);
      if (exists) {
        return prev.filter(s => s.id !== service.id);
      }
      return [...prev, service];
    });
  };

  const totalCost = useMemo(() => {
    return selectedServices.reduce((sum, service) => sum + service.prices[selectedVehicle], 0);
  }, [selectedServices, selectedVehicle]);

  const isServiceSelected = (id: string) => selectedServices.some(s => s.id === id);

  const saveRequest = () => {
    const newRequest: SavedRequest = {
      id: `REQ-${Date.now()}`,
      date: new Date().toLocaleString(),
      vehicleType: selectedVehicle,
      services: [...selectedServices],
      total: totalCost
    };
    setSavedRequests(prev => [newRequest, ...prev]);
    setSelectedServices([]);
    setIsQuoteOpen(false);
    setActiveTab('history');
  };

  const deleteRequest = (id: string) => {
    setSavedRequests(prev => prev.filter(r => r.id !== id));
  };

  const handleBulkImport = () => {
    try {
      // Simple parser for the format provided: JOB ENGINE AMHARIC Automobile LightTruck MediumTruck HeavyTruck
      const lines = importText.split('\n').filter(l => l.trim() && !l.startsWith('JOB'));
      const newServices: ServiceItem[] = lines.map(line => {
        const parts = line.split(/\s{2,}/); // Split by 2 or more spaces
        if (parts.length < 7) return null;
        return {
          id: parts[0].trim(),
          descriptionEn: parts[1].trim(),
          descriptionAm: parts[2].trim(),
          prices: {
            automobile: parseInt(parts[3].trim()) || 0,
            lightTruck: parseInt(parts[4].trim()) || 0,
            mediumTruck: parseInt(parts[5].trim()) || 0,
            heavyTruck: parseInt(parts[6].trim()) || 0,
          }
        };
      }).filter(s => s !== null) as ServiceItem[];

      if (newServices.length > 0) {
        setServices(newServices);
        setImportText('');
        alert(`Successfully imported ${newServices.length} services!`);
        setActiveTab('catalog');
      }
    } catch (e) {
      alert('Error parsing data. Please ensure the format is correct.');
    }
  };

  const resetToDefault = () => {
    if (confirm('Are you sure you want to reset to default data?')) {
      setServices(INITIAL_SERVICES);
      localStorage.removeItem('as_services');
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-slate-900 font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 px-4 py-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-xl shadow-lg shadow-indigo-200">
              <Wrench className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">AutoService Pro</h1>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Offline Service Manager</p>
            </div>
          </div>

          <nav className="flex bg-slate-100 p-1 rounded-2xl">
            {[
              { id: 'catalog', label: 'Catalog', icon: FileText },
              { id: 'history', label: 'History', icon: History },
              { id: 'admin', label: 'Admin', icon: Settings },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as Tab)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                  activeTab === tab.id 
                    ? 'bg-white text-indigo-600 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-8 pb-32">
        {activeTab === 'catalog' && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            {/* Search and Vehicle Selector */}
            <div className="flex flex-col md:flex-row gap-6 mb-10">
              <div className="flex-1">
                <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-widest mb-4">Search Services</h2>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search by name, ID or Amharic..."
                    className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-[2rem] focus:ring-2 focus:ring-indigo-500 transition-all outline-none shadow-sm"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <div className="md:w-1/2">
                <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-widest mb-4">Vehicle Type</h2>
                <div className="grid grid-cols-4 gap-2">
                  {VEHICLE_TYPES.map((type) => {
                    const Icon = type.icon;
                    const isActive = selectedVehicle === type.id;
                    return (
                      <button
                        key={type.id}
                        onClick={() => setSelectedVehicle(type.id)}
                        className={`flex flex-col items-center justify-center p-3 rounded-2xl border-2 transition-all ${
                          isActive 
                            ? 'bg-indigo-50 border-indigo-600 text-indigo-700' 
                            : 'bg-white border-transparent text-slate-400 hover:border-slate-200'
                        }`}
                      >
                        <Icon className="w-5 h-5 mb-1" />
                        <span className="text-[10px] font-bold uppercase">{type.label.split(' ')[0]}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Services Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <AnimatePresence mode="popLayout">
                {filteredServices.map((service) => (
                  <motion.div
                    key={service.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`p-5 rounded-3xl border transition-all ${
                      isServiceSelected(service.id)
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-xl shadow-indigo-200'
                        : 'bg-white border-slate-100 hover:border-indigo-200'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex-1">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full mb-2 inline-block ${
                          isServiceSelected(service.id) ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {service.id}
                        </span>
                        <h3 className="font-bold text-lg leading-tight mb-1">{service.descriptionEn}</h3>
                        <p className={`text-sm font-medium font-amharic ${
                          isServiceSelected(service.id) ? 'text-indigo-100' : 'text-slate-500'
                        }`}>
                          {service.descriptionAm}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-black tracking-tighter">
                          {service.prices[selectedVehicle].toLocaleString()}
                        </div>
                        <div className="text-[10px] font-bold uppercase opacity-60">ETB</div>
                      </div>
                    </div>
                    <button
                      onClick={() => toggleService(service)}
                      className={`mt-6 w-full py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                        isServiceSelected(service.id)
                          ? 'bg-white text-indigo-600'
                          : 'bg-slate-900 text-white hover:bg-slate-800'
                      }`}
                    >
                      {isServiceSelected(service.id) ? <CheckCircle2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                      {isServiceSelected(service.id) ? 'Selected' : 'Add to Quote'}
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {activeTab === 'history' && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-black tracking-tight">Request History</h2>
              <button 
                onClick={() => {
                  const data = JSON.stringify(savedRequests, null, 2);
                  const blob = new Blob([data], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `auto-requests-${Date.now()}.json`;
                  a.click();
                }}
                className="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700"
              >
                <Download className="w-4 h-4" />
                Export All
              </button>
            </div>

            {savedRequests.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-[3rem] border border-dashed border-slate-200">
                <History className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-slate-900">No saved requests</h3>
                <p className="text-slate-500">Quotes you save will appear here</p>
              </div>
            ) : (
              savedRequests.map((req) => (
                <div key={req.id} className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="bg-slate-100 p-3 rounded-2xl">
                        <Receipt className="w-6 h-6 text-slate-600" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">{req.id}</span>
                          <span className="text-xs font-medium text-slate-400">{req.date}</span>
                        </div>
                        <h3 className="font-bold text-lg capitalize">{req.vehicleType.replace(/([A-Z])/g, ' $1')}</h3>
                        <p className="text-sm text-slate-500">{req.services.length} services included</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between md:justify-end gap-6">
                      <div className="text-right">
                        <div className="text-2xl font-black tracking-tighter text-slate-900">{req.total.toLocaleString()} ETB</div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Amount</div>
                      </div>
                      <button 
                        onClick={() => deleteRequest(req.id)}
                        className="p-3 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </motion.div>
        )}

        {activeTab === 'admin' && (
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="max-w-2xl mx-auto">
            <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-xl">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-indigo-100 p-2 rounded-xl">
                  <Upload className="text-indigo-600 w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black tracking-tight text-slate-900">Bulk Data Import</h2>
              </div>
              
              <p className="text-sm text-slate-500 mb-6 leading-relaxed">
                Paste your service list below. The format should be: <br/>
                <code className="bg-slate-50 px-2 py-1 rounded text-indigo-600 font-bold">JOB  ENGINE  AMHARIC  Automobile  LightTruck  MediumTruck  HeavyTruck</code>
              </p>

              <textarea
                value={importText}
                onChange={(e) => setImportText(e.target.value)}
                placeholder="A001   PERFORM GENERAL SERVICE A   ጠቅላላ ሰርቪስ A   2700   3600   3600   5400..."
                className="w-full h-64 p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-xs mb-6"
              />

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleBulkImport}
                  disabled={!importText.trim()}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all"
                >
                  <Save className="w-5 h-5" />
                  Import and Update Catalog
                </button>
                <button
                  onClick={resetToDefault}
                  className="px-6 py-4 rounded-2xl font-bold text-slate-500 hover:bg-slate-50 transition-all"
                >
                  Reset to Default
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </main>

      {/* Floating Quote Summary */}
      <AnimatePresence>
        {selectedServices.length > 0 && activeTab === 'catalog' && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-2xl z-40"
          >
            <div className="bg-slate-900 text-white rounded-[2.5rem] p-4 shadow-2xl shadow-slate-900/40 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4 pl-4">
                <div className="bg-indigo-500 p-3 rounded-2xl">
                  <Receipt className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Selected</div>
                  <div className="text-xl font-black tracking-tight">{selectedServices.length} Items</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Total</div>
                  <div className="text-2xl font-black tracking-tighter text-indigo-400">{totalCost.toLocaleString()} ETB</div>
                </div>
                <button
                  onClick={() => setIsQuoteOpen(true)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-4 rounded-[1.75rem] font-bold text-sm transition-all flex items-center gap-2"
                >
                  View Quote
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quote Modal */}
      <AnimatePresence>
        {isQuoteOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsQuoteOpen(false)} className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0, y: 20 }} className="relative w-full max-w-xl bg-white rounded-[3rem] overflow-hidden shadow-2xl">
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-black tracking-tight">Current Quote</h2>
                  <button onClick={() => setIsQuoteOpen(false)} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-6 h-6 text-slate-400" /></button>
                </div>

                <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                  {selectedServices.map((service) => (
                    <div key={service.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div>
                        <div className="font-bold text-slate-900">{service.descriptionEn}</div>
                        <div className="text-xs text-slate-500 font-amharic">{service.descriptionAm}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-black tracking-tight">{service.prices[selectedVehicle].toLocaleString()} ETB</div>
                        <button onClick={() => toggleService(service)} className="text-[10px] font-bold text-red-500 uppercase hover:underline">Remove</button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 pt-8 border-t border-slate-100">
                  <div className="flex items-center justify-between mb-8">
                    <div className="text-sm font-bold text-slate-400 uppercase tracking-widest">Total Estimate</div>
                    <div className="text-4xl font-black tracking-tighter text-indigo-600">{totalCost.toLocaleString()} ETB</div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => setIsQuoteOpen(false)} className="py-4 rounded-2xl font-bold text-slate-500 hover:bg-slate-50">Cancel</button>
                    <button onClick={saveRequest} className="bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-600/20">Save Request</button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style>{`
        .font-amharic { font-family: 'Noto Sans Ethiopic', sans-serif; }
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
}
