export interface ServiceItem {
  id: string;
  descriptionEn: string;
  descriptionAm: string;
  prices: {
    automobile: number;
    lightTruck: number;
    mediumTruck: number;
    heavyTruck: number;
  };
}

export const SERVICES: ServiceItem[] = [
  {
    id: "A001",
    descriptionEn: "PERFORM GENERAL SERVICE A",
    descriptionAm: "ጠቅላላ ሰርቪስ A",
    prices: {
      automobile: 2700,
      lightTruck: 3600,
      mediumTruck: 3600,
      heavyTruck: 5400,
    },
  },
  {
    id: "A002",
    descriptionEn: "PERFORM GENERAL SERVICE B",
    descriptionAm: "ጠቅላላ ሰርቪስ B",
    prices: {
      automobile: 3600,
      lightTruck: 5400,
      mediumTruck: 6300,
      heavyTruck: 8100,
    },
  },
  {
    id: "A003",
    descriptionEn: "OIL AND FILTER CHANGE",
    descriptionAm: "የዘይት እና የፊልተር ቅያሬ",
    prices: {
      automobile: 1200,
      lightTruck: 1800,
      mediumTruck: 2200,
      heavyTruck: 3000,
    },
  },
  {
    id: "A004",
    descriptionEn: "BRAKE SYSTEM INSPECTION & ADJUSTMENT",
    descriptionAm: "የፍሬን ምርመራ እና ማስተካከያ",
    prices: {
      automobile: 1500,
      lightTruck: 2000,
      mediumTruck: 2500,
      heavyTruck: 3500,
    },
  },
  {
    id: "A005",
    descriptionEn: "ENGINE TUNE UP",
    descriptionAm: "የሞተር ማስተካከያ (ቲዩን አፕ)",
    prices: {
      automobile: 4500,
      lightTruck: 6000,
      mediumTruck: 7500,
      heavyTruck: 10000,
    },
  },
  {
    id: "A006",
    descriptionEn: "SUSPENSION SYSTEM REPAIR",
    descriptionAm: "የሳስፔንሽን ሲስተም ጥገና",
    prices: {
      automobile: 3000,
      lightTruck: 4500,
      mediumTruck: 5500,
      heavyTruck: 7500,
    },
  },
  {
    id: "A007",
    descriptionEn: "TRANSMISSION FLUID REPLACEMENT",
    descriptionAm: "የትራንስሚሽን ዘይት ቅያሬ",
    prices: {
      automobile: 2500,
      lightTruck: 3500,
      mediumTruck: 4500,
      heavyTruck: 6000,
    },
  },
  {
    id: "A008",
    descriptionEn: "COOLING SYSTEM FLUSH",
    descriptionAm: "የራዲያተር እና የማቀዝቀዣ ሲስተም ማጽዳት",
    prices: {
      automobile: 1800,
      lightTruck: 2500,
      mediumTruck: 3000,
      heavyTruck: 4000,
    },
  },
  {
    id: "A009",
    descriptionEn: "WHEEL ALIGNMENT & BALANCING",
    descriptionAm: "የጎማ አሰላለፍ እና ባላንስ",
    prices: {
      automobile: 2200,
      lightTruck: 3000,
      mediumTruck: 3500,
      heavyTruck: 4500,
    },
  },
  {
    id: "A010",
    descriptionEn: "ELECTRICAL SYSTEM DIAGNOSIS",
    descriptionAm: "የኤሌክትሪክ ሲስተም ምርመራ",
    prices: {
      automobile: 2000,
      lightTruck: 2800,
      mediumTruck: 3500,
      heavyTruck: 5000,
    },
  },
];
